@echo off
chcp 1251 >nul 2>&1
title Network Blocker Launcher

:: ============================================================
:: АВТОМАТИЧНЕ ВИЗНАЧЕННЯ ШЛЯХУ ДО СКРИПТА
:: ============================================================

:: Шукаємо скрипт поруч із цим bat-файлом
set "SCRIPT=%~dp0network_blocker.py"

:: Якщо не знайдено поруч — шукаємо на робочому столі
if not exist "%SCRIPT%" (
    for /f "tokens=2*" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders" /v Desktop 2^>nul') do (
        set "DESKTOP=%%b"
    )
    if defined DESKTOP (
        for /r "%DESKTOP%" %%f in (network_blocker.py) do (
            set "SCRIPT=%%f"
            goto :found
        )
    )
)

:: Якщо досі не знайдено — шукаємо в поточній папці та підпапках
if not exist "%SCRIPT%" (
    for /r "%~dp0" %%f in (network_blocker.py) do (
        set "SCRIPT=%%f"
        goto :found
    )
)

:: Шукаємо у всіх звичних місцях
if not exist "%SCRIPT%" (
    for %%d in (
        "%USERPROFILE%\Desktop"
        "%USERPROFILE%\OneDrive\Desktop"
        "%USERPROFILE%\Downloads"
        "C:\"
        "D:\"
    ) do (
        if exist "%%d" (
            for /r "%%d" %%f in (network_blocker.py) do (
                set "SCRIPT=%%f"
                goto :found
            )
        )
    )
)

:found

:: Якщо файл не знайдено — запитуємо шлях вручну
if not exist "%SCRIPT%" (
    echo ============================================================
    echo   ФАЙЛ network_blocker.py НЕ ЗНАЙДЕНО
    echo ============================================================
    echo.
    echo   Перетягніть файл network_blocker.py сюди і натисніть Enter:
    echo.
    set /p "SCRIPT="
    :: Забираємо лапки якщо є
    set "SCRIPT=%SCRIPT:"=%"
)

:: Фінальна перевірка
if not exist "%SCRIPT%" (
    echo.
    echo   [ПОМИЛКА] Файл не знайдено!
    pause
    exit /b 1
)

echo ============================================================
echo   NETWORK BLOCKER LAUNCHER
echo ============================================================
echo.
echo   Скрипт: %SCRIPT%
echo.

:: ============================================================
:: ЗАПУСК З ПРАВАМИ АДМІНІСТРАТОРА
:: ============================================================

:: Перевірка прав
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo   [*] Запит прав адмiнiстратора...
    powershell -Command "Start-Process cmd -ArgumentList '/c chcp 1251 ^>nul ^&^& python \"%SCRIPT%\" ^&^& pause' -Verb RunAs"
    exit /b 0
)

:: Запуск
echo   [*] Запуск скрипта...
echo.
python "%SCRIPT%"

pause