"""
Blackbox Research Project — Network Vulnerability Assessment Tool v2.3
No external dependencies. Pure Python 3.8+ standard library only.
Performs comprehensive local network vulnerability scanning.
"""

import socket
import struct
import subprocess
import platform
import threading
import queue
import time
import sys
import os
import re
import ipaddress
import concurrent.futures
from collections import namedtuple

# ============================================================
# DATA STRUCTURES
# ============================================================

NetworkInterface = namedtuple('NetworkInterface', [
    'name', 'ip', 'netmask', 'cidr', 'mac', 'is_up', 'gateway'
])

PortResult = namedtuple('PortResult', [
    'port', 'service', 'state', 'banner'
])

ScanResult = namedtuple('ScanResult', [
    'host', 'hostname', 'open_ports', 'os_guess', 'vulnerabilities'
])

# ============================================================
# SERVICE DETECTION DATABASE
# ============================================================

SERVICE_SIGNATURES = {
    21: {'service': 'FTP', 'banner_check': True, 'default_banner': '220'},
    22: {'service': 'SSH', 'banner_check': True, 'default_banner': 'SSH'},
    23: {'service': 'Telnet', 'banner_check': True, 'default_banner': 'Login'},
    25: {'service': 'SMTP', 'banner_check': True, 'default_banner': '220'},
    53: {'service': 'DNS', 'banner_check': False},
    80: {'service': 'HTTP', 'banner_check': True, 'default_banner': 'HTTP'},
    110: {'service': 'POP3', 'banner_check': True, 'default_banner': '+OK'},
    111: {'service': 'RPC', 'banner_check': False},
    135: {'service': 'MSRPC', 'banner_check': False},
    139: {'service': 'NetBIOS', 'banner_check': True},
    143: {'service': 'IMAP', 'banner_check': True, 'default_banner': '* OK'},
    389: {'service': 'LDAP', 'banner_check': False},
    443: {'service': 'HTTPS', 'banner_check': True, 'default_banner': 'HTTP'},
    445: {'service': 'SMB', 'banner_check': True},
    465: {'service': 'SMTPS', 'banner_check': True},
    514: {'service': 'RSH', 'banner_check': False},
    587: {'service': 'SMTP Submission', 'banner_check': True},
    631: {'service': 'IPP/CUPS', 'banner_check': False},
    993: {'service': 'IMAPS', 'banner_check': True},
    995: {'service': 'POP3S', 'banner_check': True},
    1080: {'service': 'SOCKS Proxy', 'banner_check': False},
    1433: {'service': 'MSSQL', 'banner_check': True},
    1521: {'service': 'Oracle DB', 'banner_check': True},
    1723: {'service': 'PPTP', 'banner_check': False},
    2049: {'service': 'NFS', 'banner_check': False},
    3128: {'service': 'HTTP Proxy', 'banner_check': True},
    3306: {'service': 'MySQL', 'banner_check': True},
    3389: {'service': 'RDP', 'banner_check': True},
    5432: {'service': 'PostgreSQL', 'banner_check': True},
    5900: {'service': 'VNC', 'banner_check': True},
    5985: {'service': 'WinRM HTTP', 'banner_check': False},
    5986: {'service': 'WinRM HTTPS', 'banner_check': False},
    6379: {'service': 'Redis', 'banner_check': True},
    8080: {'service': 'HTTP-Alt', 'banner_check': True},
    8443: {'service': 'HTTPS-Alt', 'banner_check': True},
    9090: {'service': 'Webmin', 'banner_check': True},
    9200: {'service': 'Elasticsearch', 'banner_check': True},
    27017: {'service': 'MongoDB', 'banner_check': True},
    50000: {'service': 'SAP', 'banner_check': False},
    50070: {'service': 'Hadoop', 'banner_check': False},
}

COMMON_PORTS = list(SERVICE_SIGNATURES.keys()) + [
    7, 13, 17, 19, 37, 49, 67, 68, 69, 70, 79, 88, 102, 113, 118, 119,
    123, 137, 138, 158, 161, 162, 179, 194, 199, 201, 209, 210, 213,
    218, 220, 259, 264, 311, 318, 366, 369, 370, 401, 427, 434, 443,
    444, 445, 464, 465, 497, 500, 512, 513, 515, 520, 524, 525, 530,
    531, 532, 533, 540, 543, 544, 546, 547, 554, 556, 560, 563, 587,
    591, 593, 604, 623, 631, 636, 639, 646, 647, 648, 666, 691, 692,
    694, 698, 699, 700, 701, 702, 706, 711, 712, 749, 750, 751, 752,
    754, 760, 782, 783, 808, 843, 873, 888, 898, 900, 901, 902, 903,
    911, 953, 989, 990, 991, 992, 993, 995, 1025, 1026, 1027, 1028,
    1029, 1050, 1080, 1085, 1100, 1152, 1214, 1241, 1311, 1337, 1414,
    1433, 1434, 1494, 1521, 1524, 1645, 1646, 1701, 1717, 1718, 1719,
    1720, 1723, 1755, 1761, 1801, 1812, 1813, 1883, 1900, 1985, 2000,
    2002, 2049, 2053, 2082, 2083, 2095, 2096, 2100, 2121, 2181, 2200,
    2222, 2301, 2302, 2375, 2376, 2381, 2401, 2483, 2484, 2601, 2604,
    2710, 2809, 2947, 2967, 3000, 3001, 3128, 3260, 3306, 3333, 3389,
    3396, 3455, 3689, 3690, 3780, 3899, 4000, 4040, 4100, 4200, 4242,
    4321, 4443, 4444, 4500, 4567, 4662, 4713, 4730, 4848, 4885, 4899,
    4998, 5000, 5001, 5002, 5003, 5004, 5005, 5050, 5060, 5061, 5100,
    5101, 5104, 5105, 5190, 5222, 5269, 5280, 5353, 5355, 5400, 5432,
    5500, 5550, 5555, 5556, 5631, 5632, 5672, 5683, 5800, 5801, 5900,
    5901, 5985, 5986, 6000, 6001, 6082, 6346, 6347, 6379, 6443, 6500,
    6660, 6667, 6668, 6669, 7000, 7001, 7002, 7070, 7100, 7200, 7210,
    7396, 7435, 7474, 7512, 7777, 8000, 8008, 8009, 8010, 8080, 8081,
    8086, 8087, 8088, 8089, 8090, 8181, 8200, 8333, 8443, 8484, 8500,
    8580, 8649, 8765, 8880, 8888, 8937, 8983, 9000, 9001, 9042, 9050,
    9051, 9060, 9080, 9090, 9091, 9100, 9150, 9191, 9200, 9300, 9418,
    9443, 9535, 9800, 9999, 10000, 10050, 10051, 10443, 11211, 11300,
    11371, 12000, 12345, 12975, 13720, 13721, 13722, 13724, 13782,
    13783, 15000, 15660, 16379, 16992, 16993, 18091, 18092, 20000,
    20547, 21025, 21379, 22181, 23720, 25000, 26000, 27017, 27018,
    27019, 28015, 28017, 28960, 31337, 32400, 32768, 37777, 44134,
    44818, 47808, 49152, 49153, 49154, 50000, 50030, 50060, 50070,
    50075, 50090, 50100, 51111, 54321, 55553, 60000, 61616, 62078,
    64738,
]

# ============================================================
# VULNERABILITY ASSESSMENT RULES
# ============================================================

class VulnerabilityRule:
    def __init__(self, name, severity, description, condition_fn):
        self.name = name
        self.severity = severity
        self.description = description
        self.condition_fn = condition_fn

VULNERABILITY_RULES = [
    VulnerabilityRule(
        "Telnet Service Detected",
        "HIGH",
        "Telnet transmits all data (including credentials) in cleartext. Replace with SSH immediately.",
        lambda ports: any(p.port == 23 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "FTP Cleartext Authentication",
        "MEDIUM",
        "FTP transmits credentials in plaintext. Use SFTP/FTPS instead.",
        lambda ports: any(p.port == 21 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "SMBv1 Potentially Enabled",
        "CRITICAL",
        "SMBv1 is vulnerable to EternalBlue (MS17-010) and WannaCry exploits. Disable SMBv1 immediately.",
        lambda ports: any(p.port == 445 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "MySQL Default Port Open",
        "MEDIUM",
        "MySQL exposed to network. Ensure strong authentication and consider binding to localhost only.",
        lambda ports: any(p.port == 3306 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "RDP Exposed",
        "HIGH",
        "RDP exposed to network. Brute force target. Ensure Network Level Authentication (NLA) is enforced and account lockout policies are active.",
        lambda ports: any(p.port == 3389 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "HTTP Without TLS",
        "MEDIUM",
        "Unencrypted HTTP traffic can be intercepted. Redirect to HTTPS or restrict access.",
        lambda ports: any(p.port == 80 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "VNC Without Authentication",
        "HIGH",
        "VNC often configured without passwords. Verify authentication is required.",
        lambda ports: any(p.port in [5900, 5901, 5800, 5801] and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "MongoDB Default Port Exposed",
        "CRITICAL",
        "MongoDB without authentication. Potential data breach. Enable authentication and firewall restrictions.",
        lambda ports: any(p.port == 27017 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "Redis Default Port Exposed",
        "HIGH",
        "Redis often deployed without authentication. Potential for data access and server compromise.",
        lambda ports: any(p.port == 6379 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "Elasticsearch Exposed",
        "HIGH",
        "Elasticsearch contains sensitive data. Unauthenticated access allows data exfiltration.",
        lambda ports: any(p.port == 9200 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "Multiple Database Services",
        "MEDIUM",
        "Multiple database services detected. Increases attack surface. Consolidate or restrict access.",
        lambda ports: sum(1 for p in ports if p.port in [1433, 1521, 3306, 5432, 6379, 27017]) > 1
    ),
    VulnerabilityRule(
        "UPnP/SSDP Exposed",
        "LOW",
        "UPnP can be exploited for DDoS amplification and NAT traversal attacks.",
        lambda ports: any(p.port == 1900 and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "NetBIOS Exposed",
        "MEDIUM",
        "NetBIOS reveals system information useful for reconnaissance. Block ports 137-139 if not needed.",
        lambda ports: any(p.port in [137, 138, 139] and p.state == 'open' for p in ports)
    ),
    VulnerabilityRule(
        "LDAP Without Encryption",
        "MEDIUM",
        "Unencrypted LDAP transmits directory data in cleartext. Use LDAPS on port 636.",
        lambda ports: any(p.port == 389 and p.state == 'open' and not any(p2.port == 636 for p2 in ports))
    ),
    VulnerabilityRule(
        "NFS Exposed",
        "HIGH",
        "NFS file shares may be accessible without authentication. Verify export restrictions.",
        lambda ports: any(p.port == 2049 and p.state == 'open' for p in ports)
    ),
]

# ============================================================
# NETWORK UTILITIES
# ============================================================

def get_local_ip():
    """Determine the primary local IP address by connecting to an external address."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return '127.0.0.1'


def get_default_gateway():
    """Detect the default gateway using platform-specific methods."""
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(
                ['ipconfig'],
                capture_output=True,
                text=True,
                timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            output = result.stdout
            for line in output.splitlines():
                if 'Default Gateway' in line:
                    parts = line.split(':')
                    if len(parts) > 1:
                        gw = parts[-1].strip()
                        if gw and gw != '0.0.0.0' and '.' in gw:
                            return gw
        elif system == 'Linux':
            for route_file in ['/proc/net/route', '/proc/net/ipv6_route']:
                try:
                    with open('/proc/net/route', 'r') as f:
                        lines = f.readlines()
                    if len(lines) > 1:
                        for line in lines[1:]:
                            fields = line.strip().split()
                            if len(fields) >= 11:
                                dest = struct.unpack('<I', bytes.fromhex(fields[1]))[0]
                                gw = struct.unpack('<I', bytes.fromhex(fields[2]))[0]
                                if dest == 0:
                                    return socket.inet_ntoa(struct.pack('<I', gw))
                except Exception:
                    pass
        else:
            result = subprocess.run(
                ['netstat', '-rn'],
                capture_output=True,
                text=True,
                timeout=10
            )
            output = result.stdout
            for line in output.splitlines():
                if 'default' in line.lower() or '0.0.0.0' in line:
                    parts = line.split()
                    for i, part in enumerate(parts):
                        if part.lower() == 'default' and i + 1 < len(parts):
                            return parts[i + 1]
    except Exception:
        pass

    return None


def get_network_interfaces():
    """Enumerate all network interfaces with IP, netmask, MAC."""
    interfaces = []
    system = platform.system()

    try:
        if system == 'Windows':
            result = subprocess.run(
                ['ipconfig', '/all'],
                capture_output=True,
                text=True,
                timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            output = result.stdout
            current_adapter = None
            current_ip = None
            current_mask = None
            current_mac = None
            current_up = False

            for line in output.splitlines():
                line_stripped = line.strip()

                if 'adapter' in line_stripped.lower() and ':' in line_stripped:
                    if current_adapter:
                        cidr = None
                        if current_ip and current_mask:
                            try:
                                cidr = ipaddress.IPv4Network(f"{current_ip}/{current_mask}", strict=False).prefixlen
                            except Exception:
                                cidr = 24
                        interfaces.append(NetworkInterface(
                            name=current_adapter,
                            ip=current_ip or '0.0.0.0',
                            netmask=current_mask or '255.255.255.0',
                            cidr=cidr or 24,
                            mac=current_mac or 'Unknown',
                            is_up=current_up,
                            gateway=None
                        ))
                    current_adapter = line_stripped.split(':')[0].strip()
                    current_ip = None
                    current_mask = None
                    current_mac = None
                    current_up = False

                if 'IPv4 Address' in line_stripped:
                    parts = line_stripped.split(':')
                    if len(parts) > 1:
                        ip_val = parts[-1].strip()
                        if '(' in ip_val:
                            ip_val = ip_val.split('(')[0].strip()
                        current_ip = ip_val
                        current_up = True

                if 'Subnet Mask' in line_stripped:
                    parts = line_stripped.split(':')
                    if len(parts) > 1:
                        current_mask = parts[-1].strip()

                if 'Physical Address' in line_stripped:
                    parts = line_stripped.split(':')
                    if len(parts) > 1:
                        current_mac = parts[-1].strip()

            if current_adapter:
                cidr = None
                if current_ip and current_mask:
                    try:
                        cidr = ipaddress.IPv4Network(f"{current_ip}/{current_mask}", strict=False).prefixlen
                    except Exception:
                        cidr = 24
                interfaces.append(NetworkInterface(
                    name=current_adapter,
                    ip=current_ip or '0.0.0.0',
                    netmask=current_mask or '255.255.255.0',
                    cidr=cidr or 24,
                    mac=current_mac or 'Unknown',
                    is_up=current_up,
                    gateway=None
                ))

        elif system in ['Linux', 'Darwin']:
            if system == 'Linux':
                if_cmd = ['ip', 'addr', 'show']
            else:
                if_cmd = ['ifconfig']

            result = subprocess.run(
                if_cmd,
                capture_output=True,
                text=True,
                timeout=10
            )
            output = result.stdout

            current_iface = None
            current_ip = None
            current_mask = None
            current_mac = None

            for line in output.splitlines():
                line_stripped = line.strip()

                if line and not line.startswith(' ') and not line.startswith('\t'):
                    if current_iface:
                        cidr = None
                        if current_ip and current_mask:
                            try:
                                cidr = ipaddress.IPv4Network(f"{current_ip}/{current_mask}", strict=False).prefixlen
                            except Exception:
                                cidr = 24
                        interfaces.append(NetworkInterface(
                            name=current_iface,
                            ip=current_ip or '0.0.0.0',
                            netmask=current_mask or '255.255.255.0',
                            cidr=cidr or 24,
                            mac=current_mac or 'Unknown',
                            is_up=current_ip is not None,
                            gateway=None
                        ))
                    parts = line.split(':')
                    if parts:
                        current_iface = parts[0].strip()
                    current_ip = None
                    current_mask = None
                    current_mac = None

                if 'inet ' in line_stripped and 'inet6' not in line_stripped:
                    parts = line_stripped.split()
                    for i, part in enumerate(parts):
                        if part == 'inet' and i + 1 < len(parts):
                            addr = parts[i + 1]
                            if '/' in addr:
                                ip_part, cidr_part = addr.split('/')
                                current_ip = ip_part
                                try:
                                    current_mask = str(ipaddress.IPv4Network(f"0.0.0.0/{cidr_part}").netmask)
                                except Exception:
                                    current_mask = '255.255.255.0'
                            else:
                                current_ip = addr
                                current_mask = '255.255.255.0'

                if 'ether' in line_stripped.lower():
                    parts = line_stripped.split()
                    for i, part in enumerate(parts):
                        if part.lower() == 'ether' and i + 1 < len(parts):
                            current_mac = parts[i + 1]

            if current_iface:
                cidr = None
                if current_ip and current_mask:
                    try:
                        cidr = ipaddress.IPv4Network(f"{current_ip}/{current_mask}", strict=False).prefixlen
                    except Exception:
                        cidr = 24
                interfaces.append(NetworkInterface(
                    name=current_iface,
                    ip=current_ip or '0.0.0.0',
                    netmask=current_mask or '255.255.255.0',
                    cidr=cidr or 24,
                    mac=current_mac or 'Unknown',
                    is_up=current_ip is not None,
                    gateway=None
                ))
    except Exception:
        pass

    gateway = get_default_gateway()
    for i in range(len(interfaces)):
        interfaces[i] = NetworkInterface(
            name=interfaces[i].name,
            ip=interfaces[i].ip,
            netmask=interfaces[i].netmask,
            cidr=interfaces[i].cidr,
            mac=interfaces[i].mac,
            is_up=interfaces[i].is_up,
            gateway=gateway if gateway and interfaces[i].is_up else interfaces[i].gateway
        )

    return interfaces


def calculate_network_range(ip, netmask):
    """Calculate all host IPs in the subnet."""
    try:
        cidr = ipaddress.IPv4Network(f"{ip}/{netmask}", strict=False).prefixlen
    except Exception:
        cidr = 24
    try:
        network = ipaddress.IPv4Network(f"{ip}/{cidr}", strict=False)
        hosts = [str(h) for h in network.hosts()]
        return hosts, str(network.network_address), str(network.broadcast_address)
    except Exception:
        return [ip], ip, ip


# ============================================================
# SCANNING ENGINE
# ============================================================

def tcp_connect_scan(host, port, timeout=1.5):
    """Perform TCP connect scan on a single port."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception:
        return False


def grab_banner(host, port, timeout=2.0):
    """Attempt to grab service banner from open port."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.settimeout(timeout)
        sock.connect((host, port))
        sock.send(b'\r\n')
        time.sleep(0.3)
        sock.settimeout(1.0)
        banner = b''
        while True:
            try:
                data = sock.recv(1024)
                if not data:
                    break
                banner += data
                if len(banner) >= 2048:
                    break
            except socket.timeout:
                break
            except Exception:
                break
        sock.close()
        decoded = banner.decode('utf-8', errors='ignore').strip()
        if decoded:
            cleaned = re.sub(r'[\r\n\t]+', ' ', decoded)[:200]
            return cleaned
    except Exception:
        pass
    return None


def scan_host(host, ports, timeout=1.0):
    """Scan a single host for open ports with banner grabbing."""
    open_ports = []
    for port in ports:
        if tcp_connect_scan(host, port, timeout):
            service_name = SERVICE_SIGNATURES.get(port, {}).get('service', 'unknown')
            banner = grab_banner(host, port)
            open_ports.append(PortResult(port=port, service=service_name, state='open', banner=banner))
    return open_ports


def resolve_hostname(host):
    """Resolve hostname from IP address."""
    try:
        return socket.gethostbyaddr(host)[0]
    except Exception:
        return host


def ping_host(host, timeout=0.5):
    """Check if host is alive using TCP ping on port 445 and 139 as fallback."""
    for port in [445, 139, 135, 22, 80]:
        if tcp_connect_scan(host, port, timeout):
            return True
    return False


def determine_os(host, open_ports):
    """Basic OS fingerprinting based on open ports."""
    port_set = {p.port for p in open_ports}
    score_windows = 0
    score_linux = 0

    if 445 in port_set: score_windows += 3
    if 139 in port_set: score_windows += 2
    if 135 in port_set: score_windows += 2
    if 3389 in port_set: score_windows += 2
    if 5985 in port_set or 5986 in port_set: score_windows += 1

    if 22 in port_set: score_linux += 3
    if 111 in port_set: score_linux += 2
    if 2049 in port_set: score_linux += 2
    if 631 in port_set: score_linux += 1

    if score_windows > score_linux:
        return "Windows"
    elif score_linux > score_windows:
        return "Linux/Unix"
    elif score_windows > 0 and score_linux > 0:
        return "Mixed/Unknown"
    else:
        return "Unknown"


# ============================================================
# DNS / NETWORK ENUMERATION
# ============================================================

def enumerate_dns_servers():
    """Identify DNS servers configured on the system."""
    dns_servers = []
    system = platform.system()

    try:
        if system == 'Windows':
            result = subprocess.run(
                ['ipconfig', '/all'],
                capture_output=True,
                text=True,
                timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            for line in result.stdout.splitlines():
                if 'DNS Servers' in line or 'DNS Server' in line:
                    parts = line.split(':')
                    if len(parts) > 1:
                        server = parts[-1].strip()
                        if server and '.' in server:
                            dns_servers.append(server)
        elif system in ['Linux', 'Darwin']:
            resolv_path = '/etc/resolv.conf'
            if os.path.exists(resolv_path):
                with open(resolv_path, 'r') as f:
                    for line in f:
                        if line.startswith('nameserver'):
                            parts = line.split()
                            if len(parts) > 1:
                                dns_servers.append(parts[1])
    except Exception:
        pass

    return dns_servers


def enumerate_listening_ports():
    """Enumerate listening ports on local machine using netstat/ss."""
    listening = []
    system = platform.system()

    try:
        if system == 'Windows':
            result = subprocess.run(
                ['netstat', '-ano', '-p', 'TCP'],
                capture_output=True,
                text=True,
                timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            lines = result.stdout.splitlines()
            for line in lines:
                if 'LISTENING' in line:
                    parts = line.split()
                    if len(parts) >= 2:
                        addr_port = parts[1]
                        if ':' in addr_port:
                            port_str = addr_port.rsplit(':', 1)[-1]
                            try:
                                port = int(port_str)
                                listening.append(port)
                            except ValueError:
                                pass
        elif system in ['Linux', 'Darwin']:
            result = subprocess.run(
                ['ss', '-tlnp'] if system == 'Linux' else ['netstat', '-an', '-p', 'tcp'],
                capture_output=True,
                text=True,
                timeout=10
            )
            for line in result.stdout.splitlines():
                if 'LISTEN' in line:
                    parts = line.split()
                    for part in parts:
                        if ':' in part and not part.startswith('*'):
                            port_str = part.rsplit(':', 1)[-1]
                            try:
                                port = int(port_str)
                                listening.append(port)
                                break
                            except ValueError:
                                continue
    except Exception:
        pass

    return sorted(set(listening))


# ============================================================
# REPORT GENERATION
# ============================================================

class Colors:
    """ANSI color codes for terminal output."""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'

    @staticmethod
    def disable():
        Colors.HEADER = ''
        Colors.BLUE = ''
        Colors.CYAN = ''
        Colors.GREEN = ''
        Colors.YELLOW = ''
        Colors.RED = ''
        Colors.BOLD = ''
        Colors.UNDERLINE = ''
        Colors.RESET = ''


def severity_color(severity):
    if severity == 'CRITICAL':
        return f"{Colors.RED}{Colors.BOLD}CRITICAL{Colors.RESET}"
    elif severity == 'HIGH':
        return f"{Colors.RED}HIGH{Colors.RESET}"
    elif severity == 'MEDIUM':
        return f"{Colors.YELLOW}MEDIUM{Colors.RESET}"
    elif severity == 'LOW':
        return f"{Colors.GREEN}LOW{Colors.RESET}"
    return severity


def print_banner():
    banner = f"""
{Colors.CYAN}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════╗
║     BLACKBOX RESEARCH PROJECT — Network Vulnerability       ║
║     Assessment Tool v2.3 — Pure Python / No Dependencies    ║
║     tg: @blackbox_research                                  ║
╚══════════════════════════════════════════════════════════════╝
{Colors.RESET}
"""
    print(banner)


def print_results(results, interfaces, dns_servers, listening_ports):
    """Format and print comprehensive scan results."""
    print(f"\n{Colors.BOLD}{'='*70}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.HEADER}  NETWORK TOPOLOGY{Colors.RESET}")
    print(f"{Colors.BOLD}{'='*70}{Colors.RESET}\n")

    for iface in interfaces:
        if iface.is_up:
            status = f"{Colors.GREEN}UP{Colors.RESET}"
        else:
            status = f"{Colors.RED}DOWN{Colors.RESET}"

        print(f"  Interface  : {Colors.CYAN}{iface.name}{Colors.RESET}")
        print(f"  Status     : {status}")
        print(f"  IP Address : {Colors.YELLOW}{iface.ip}{Colors.RESET}")
        print(f"  Netmask    : {iface.netmask} (/{iface.cidr})")
        print(f"  MAC        : {iface.mac}")
        if iface.gateway:
            print(f"  Gateway    : {Colors.YELLOW}{iface.gateway}{Colors.RESET}")
        print()

    if dns_servers:
        print(f"  DNS Servers: {', '.join(dns_servers)}\n")

    if listening_ports:
        print(f"  Local Listening Ports: {len(listening_ports)}")
        print(f"  {Colors.YELLOW}{', '.join(map(str, listening_ports[:30]))}{Colors.RESET}")
        if len(listening_ports) > 30:
            print(f"  ... and {len(listening_ports) - 30} more")
        print()

    print(f"\n{Colors.BOLD}{'='*70}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.HEADER}  SCAN RESULTS — {len(results)} hosts scanned{Colors.RESET}")
    print(f"{Colors.BOLD}{'='*70}{Colors.RESET}\n")

    total_vulns = 0
    critical_count = 0
    high_count = 0

    for result in results:
        if not result.open_ports:
            continue

        print(f"{Colors.BOLD}{Colors.CYAN}  Host: {result.host} ({result.hostname}){Colors.RESET}")
        print(f"  {Colors.BOLD}OS Guess: {result.os_guess}{Colors.RESET}")
        print(f"  {Colors.BOLD}Open Ports: {len(result.open_ports)}{Colors.RESET}")
        print(f"  {'-'*60}")

        for port_result in result.open_ports:
            banner_str = f" [{port_result.banner[:60]}...]" if port_result.banner else ""
            print(f"    {Colors.GREEN}●{Colors.RESET} Port {port_result.port:>6} — {port_result.service:<20} {banner_str}")

        if result.vulnerabilities:
            print(f"\n  {Colors.RED}{Colors.BOLD}  VULNERABILITIES DETECTED:{Colors.RESET}")
            for vuln in result.vulnerabilities:
                print(f"    {severity_color(vuln.severity):>10} — {vuln.name}")
                print(f"              {vuln.description}")
                total_vulns += 1
                if vuln.severity == 'CRITICAL':
                    critical_count += 1
                elif vuln.severity == 'HIGH':
                    high_count += 1
        print(f"  {'='*60}\n")

    print(f"\n{Colors.BOLD}{'='*70}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.HEADER}  SUMMARY{Colors.RESET}")
    print(f"{Colors.BOLD}{'='*70}{Colors.RESET}\n")
    print(f"  Total hosts with open ports : {sum(1 for r in results if r.open_ports)}")
    print(f"  Total open ports detected   : {sum(len(r.open_ports) for r in results)}")
    print(f"  Total vulnerabilities       : {total_vulns}")
    print(f"    {Colors.RED}Critical{Colors.RESET} : {critical_count}")
    print(f"    {Colors.RED}High{Colors.RESET}     : {high_count}")
    print(f"    {Colors.YELLOW}Medium{Colors.RESET}   : {total_vulns - critical_count - high_count}")
    print()

    if critical_count > 0:
        print(f"  {Colors.RED}{Colors.BOLD}[!] CRITICAL VULNERABILITIES FOUND — Immediate action required.{Colors.RESET}\n")
    elif high_count > 0:
        print(f"  {Colors.YELLOW}{Colors.BOLD}[!] High severity issues detected. Review recommended.{Colors.RESET}\n")
    else:
        print(f"  {Colors.GREEN}{Colors.BOLD}[✓] No critical or high severity issues detected.{Colors.RESET}\n")


def save_report(results, interfaces, dns_servers, listening_ports, filename):
    """Save scan results to a text file."""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("="*70 + "\n")
            f.write("BLACKBOX RESEARCH PROJECT — Network Vulnerability Assessment Report\n")
            f.write("="*70 + "\n\n")

            f.write("NETWORK TOPOLOGY\n")
            f.write("-"*40 + "\n")
            for iface in interfaces:
                f.write(f"Interface: {iface.name}\n")
                f.write(f"Status: {'UP' if iface.is_up else 'DOWN'}\n")
                f.write(f"IP: {iface.ip}/{iface.cidr}\n")
                f.write(f"MAC: {iface.mac}\n")
                if iface.gateway:
                    f.write(f"Gateway: {iface.gateway}\n")
                f.write("\n")

            if dns_servers:
                f.write(f"DNS Servers: {', '.join(dns_servers)}\n\n")

            if listening_ports:
                f.write(f"Local Listening Ports: {len(listening_ports)}\n")
                f.write(f"{', '.join(map(str, listening_ports))}\n\n")

            f.write("\n" + "="*70 + "\n")
            f.write("SCAN RESULTS\n")
            f.write("="*70 + "\n\n")

            for result in results:
                if not result.open_ports:
                    continue
                f.write(f"Host: {result.host} ({result.hostname})\n")
                f.write(f"OS Guess: {result.os_guess}\n")
                f.write(f"Open Ports:\n")
                for pr in result.open_ports:
                    banner_str = f" [{pr.banner}]" if pr.banner else ""
                    f.write(f"  - {pr.port} ({pr.service}){banner_str}\n")

                if result.vulnerabilities:
                    f.write(f"\nVULNERABILITIES:\n")
                    for v in result.vulnerabilities:
                        f.write(f"  [{v.severity}] {v.name}\n")
                        f.write(f"  {v.description}\n\n")
                f.write("-"*60 + "\n\n")

        print(f"{Colors.GREEN}[✓] Report saved to: {filename}{Colors.RESET}")
    except Exception as e:
        print(f"{Colors.RED}[!] Failed to save report: {e}{Colors.RESET}")


# ============================================================
# MAIN SCANNER
# ============================================================

def main():
    print_banner()

    # Get local system info
    print(f"{Colors.CYAN}[*] Enumerating network interfaces...{Colors.RESET}")
    interfaces = get_network_interfaces()
    local_ip = get_local_ip()
    gateway = get_default_gateway()

    print(f"{Colors.CYAN}[*] Enumerating DNS configuration...{Colors.RESET}")
    dns_servers = enumerate_dns_servers()

    print(f"{Colors.CYAN}[*] Enumerating local listening ports...{Colors.RESET}")
    listening_ports = enumerate_listening_ports()

    # Display interface info
    active_iface = None
    for iface in interfaces:
        if iface.is_up and iface.ip != '127.0.0.1' and iface.ip != '0.0.0.0':
            active_iface = iface
            print(f"{Colors.GREEN}[+] Active interface: {iface.name} — {iface.ip}/{iface.cidr}{Colors.RESET}")
            break

    if not active_iface:
        print(f"{Colors.RED}[!] No active network interface found. Using fallback detection.{Colors.RESET}")
        active_iface = NetworkInterface(
            name='auto', ip=local_ip, netmask='255.255.255.0',
            cidr=24, mac='Unknown', is_up=True, gateway=gateway
        )

    # Calculate network range
    print(f"{Colors.CYAN}[*] Calculating network range...{Colors.RESET}")
    hosts, network_addr, broadcast_addr = calculate_network_range(
        active_iface.ip, active_iface.netmask
    )
    print(f"{Colors.GREEN}[+] Network: {network_addr}/{active_iface.cidr}{Colors.RESET}")
    print(f"{Colors.GREEN}[+] Broadcast: {broadcast_addr}{Colors.RESET}")
    print(f"{Colors.GREEN}[+] Potential hosts: {len(hosts)}{Colors.RESET}")

    # Determine scan targets
    total_hosts = len(hosts)
    if total_hosts > 256:
        print(f"{Colors.YELLOW}[!] Large subnet detected ({total_hosts} hosts).{Colors.RESET}")
        print(f"{Colors.YELLOW}[!] Scanning first 256 hosts + gateway + local subnet.{Colors.RESET}")
        targets = hosts[:256]
    else:
        targets = hosts

    # Always include gateway and local IP
    if gateway and gateway not in targets:
        targets.insert(0, gateway)
    if local_ip not in targets:
        targets.insert(0, local_ip)

    print(f"{Colors.CYAN}[*] Target count: {len(targets)}{Colors.RESET}")
    print(f"{Colors.CYAN}[*] Port count per host: {len(COMMON_PORTS)}{Colors.RESET}")
    print(f"{Colors.CYAN}[*] Estimated scan time: ~{max(1, len(targets) * 0.5):.0f}-{max(2, len(targets) * 1.5):.0f} seconds{Colors.RESET}")

    # Choose scan mode
    print(f"\n{Colors.BOLD}Scan options:{Colors.RESET}")
    print(f"  [1] Quick scan (common ports: 21-23,53,80,443,445,3389,8080,8443)")
    print(f"  [2] Standard scan (all {len(COMMON_PORTS)} ports)")
    print(f"  [3] Custom port range")
    choice = input(f"\n{Colors.CYAN}Select scan mode [1/2/3] (default: 2): {Colors.RESET}").strip()

    if choice == '1':
        scan_ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1433, 1521, 1723, 3128, 3306, 3389, 5432, 5900, 6379, 8080, 8443, 27017]
    elif choice == '3':
        try:
            range_input = input(f"{Colors.CYAN}Enter port range (e.g., 1-1000): {Colors.RESET}").strip()
            start, end = map(int, range_input.split('-'))
            scan_ports = list(range(start, min(end + 1, 65536)))
            print(f"{Colors.GREEN}[+] Scanning ports {start}-{end} ({len(scan_ports)} ports){Colors.RESET}")
        except Exception:
            print(f"{Colors.YELLOW}[!] Invalid input. Using default port set.{Colors.RESET}")
            scan_ports = COMMON_PORTS
    else:
        scan_ports = COMMON_PORTS

    # Begin scanning
    print(f"\n{Colors.CYAN}{Colors.BOLD}[*] Starting network scan...{Colors.RESET}\n")

    results = []
    alive_count = 0
    lock = threading.Lock()
    progress_lock = threading.Lock()
    scanned_count = [0]

    def progress_callback():
        with progress_lock:
            scanned_count[0] += 1
            percent = int(scanned_count[0] / len(targets) * 100)
            bar_len = 50
            filled = int(bar_len * scanned_count[0] / len(targets))
            bar = '█' * filled + '░' * (bar_len - filled)
            sys.stdout.write(f'\r  [{bar}] {percent}% ({scanned_count[0]}/{len(targets)})  ')
            sys.stdout.flush()

    def scan_worker(target):
        try:
            if ping_host(target, 0.4):
                open_ports = scan_host(target, scan_ports, 0.8)
                if open_ports:
                    hostname = resolve_hostname(target)
                    os_guess = determine_os(target, open_ports)
                    vulnerabilities = [v for v in VULNERABILITY_RULES if v.condition_fn(open_ports)]
                    with lock:
                        nonlocal alive_count
                        alive_count += 1
                        results.append(ScanResult(
                            host=target,
                            hostname=hostname,
                            open_ports=open_ports,
                            os_guess=os_guess,
                            vulnerabilities=vulnerabilities
                        ))
        except Exception:
            pass
        progress_callback()

    start_time = time.time()

    with concurrent.futures.ThreadPoolExecutor(max_workers=200) as executor:
        futures = [executor.submit(scan_worker, target) for target in targets]
        concurrent.futures.wait(futures)

    elapsed = time.time() - start_time

    print(f"\n\n{Colors.GREEN}[+] Scan completed in {elapsed:.1f} seconds.{Colors.RESET}")
    print(f"{Colors.GREEN}[+] {alive_count} hosts responded, {sum(1 for r in results if r.open_ports)} have open ports.{Colors.RESET}")

    # Sort results by vulnerability severity
    def sort_key(result):
        if not result.vulnerabilities:
            return (5, 0)
        severity_order = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3}
        min_severity = min(severity_order.get(v.severity, 4) for v in result.vulnerabilities)
        return (min_severity, -len(result.vulnerabilities))

    results.sort(key=sort_key)

    # Print results
    print_results(results, interfaces, dns_servers, listening_ports)

    # Save report option
    save_option = input(f"{Colors.CYAN}Save report to file? [y/N]: {Colors.RESET}").strip().lower()
    if save_option == 'y':
        timestamp = time.strftime('%Y%m%d_%H%M%S')
        filename = f"blackbox_scan_{timestamp}.txt"
        save_report(results, interfaces, dns_servers, listening_ports, filename)

    print(f"\n{Colors.CYAN}{Colors.BOLD}Blackbox Research Project — Analysis complete.{Colors.RESET}")
    print(f"{Colors.CYAN}tg: @blackbox_research{Colors.RESET}\n")


if __name__ == '__main__':
    try:
        # Check for color support
        if platform.system() == 'Windows':
            os.system('color')
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.YELLOW}[!] Scan interrupted by user.{Colors.RESET}")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.RED}[!] Fatal error: {e}{Colors.RESET}")
        sys.exit(1)